export class follow {

 
    id:number;
followername:String;
    username:String;
    status:String;
   
     
     
     }
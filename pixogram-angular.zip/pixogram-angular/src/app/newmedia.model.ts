export class newmedia {

 

    title: string;
    

    description: string;
    tags: string;
    type: string;
    userid:number;
     
     
     }
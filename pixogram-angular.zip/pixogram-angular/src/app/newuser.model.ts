export class newuser {

 
 
    password: string;
    
    email: string;
    username: string;

     
     
     }
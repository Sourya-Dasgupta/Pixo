export class medianame {

 
    name: string;
    type: string;
    username: string;
  
   
    
 
     
     
     }